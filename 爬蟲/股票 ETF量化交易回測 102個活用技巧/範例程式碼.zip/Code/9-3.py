# 載入套件
import Function

# 每筆交易的損益
Profit = [5,-2,1,-3,6]

# 計算績效KPI
Function.GetKPI(Profit)
