import shutil
shutil.copy("poem.txt", "E:\\")
shutil.copy("poem.txt", "E:\\poem2.txt")
