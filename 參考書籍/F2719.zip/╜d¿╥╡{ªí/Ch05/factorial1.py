result = 1
for i in range(1, 6):
    result = result * i

print("5! =", result)
