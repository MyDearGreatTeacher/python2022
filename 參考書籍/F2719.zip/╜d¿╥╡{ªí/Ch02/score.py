score1 = eval(input("請輸入國文分數："))
score2 = eval(input("請輸入英文分數："))
score3 = eval(input("請輸入數學分數："))

total = score1 + score2 + score3
print("總成績為", total)
