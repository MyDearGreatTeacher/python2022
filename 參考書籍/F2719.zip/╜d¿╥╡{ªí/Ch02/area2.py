# 將圓周率PI定義為常數
PI = 3.14159
# 取得使用者輸入的圓半徑並轉換成數值
radius = eval(input("請輸入圓半徑："))
# 印出圓面積
print("半徑為", radius, "的圓面積為", PI * radius * radius)
