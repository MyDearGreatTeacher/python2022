# 將圓周率PI定義為常數
PI = 3.14159
# 將半徑設定為10
radius = 10
# 印出圓面積
print(PI * radius * radius)
