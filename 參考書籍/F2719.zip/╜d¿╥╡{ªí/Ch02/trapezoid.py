top = eval(input("請輸入上底："))
bottom = eval(input("請輸入下底："))
height = eval(input("請輸入高："))

area = (top + bottom) * height / 2
print("梯形面積為", area)
