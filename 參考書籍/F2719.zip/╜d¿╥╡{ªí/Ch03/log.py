# 匯入math模組
import math

# 使用math.log() 函式計算x、y的值
x = math.log(2, 10)
y = math.log(3, 10)

# 使用pow() 函式計算題目的值
result = pow(10, 2 * x + 3 * y + 1)
print("結果為", result)
