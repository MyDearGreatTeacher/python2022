char = input("請輸入字元：")
code = ord(char)
print("該字元的Unicode碼為", code)
