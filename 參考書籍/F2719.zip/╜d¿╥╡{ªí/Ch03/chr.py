code = eval(input("請輸入Unicode碼："))
char = chr(code)
print("該Unicode碼表示字元", char)
