# 當i尚未等於終止值5時，就印出i；當i等於終止值5時，就跳出迴圈
for i in range(5):
    print(i)
