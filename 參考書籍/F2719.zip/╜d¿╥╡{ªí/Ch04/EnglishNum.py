num = eval(input("請輸入1 ~ 5的整數："))
if num == 1:   
    print("ONE")
elif num == 2:
    print("TWO")
elif num == 3:
    print("THREE")
elif num == 4:
    print("FOUR")
elif num == 5:
    print("FIVE")
else:
    print("您輸入的資料超過範圍！")

