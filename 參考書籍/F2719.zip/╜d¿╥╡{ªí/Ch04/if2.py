score = eval(input("請輸入數學分數 (0 ~ 100)："))
if score >= 60:   
    print("及格！")
else:
    print("不及格！")
