i = 0
while i < 5:
    print(i)
    i = i + 1
