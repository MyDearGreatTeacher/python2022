# 取得使用者輸入的整數
num = eval(input("請輸入一個整數："))

# 判斷該整數是否為偶數
if num % 2 == 0:
    print("這是偶數")
else:
    print("這是奇數")
