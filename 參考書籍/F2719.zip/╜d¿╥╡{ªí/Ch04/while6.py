number = 1
minutes = 0
while number < 1000000:
    number *= 2
    minutes += 1  

print("該細胞在經過", minutes, "分鐘後，總數會超過一百萬個")
