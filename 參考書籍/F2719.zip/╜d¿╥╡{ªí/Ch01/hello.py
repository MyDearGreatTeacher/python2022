# -*- coding: utf-8 -*-
"""
Created on Fri Jan  7 19:58:10 2022

@author: Jean
"""

print("Hello, World!")