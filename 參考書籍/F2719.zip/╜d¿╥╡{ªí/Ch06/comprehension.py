def double(L):
    result = [i * 2 for i in L]
    return result

list1 = [0.5, 1, 2, 3, 4, 5, "ABC"]
list2 = double(list1)
print(list2)
