# F1750 練習 16

def unique_num_len(numbers):
    return len(set(numbers))

numbers = [1, 2, 3, 1, 2, 3, 4, 1, 2]
print(unique_num_len(numbers))
