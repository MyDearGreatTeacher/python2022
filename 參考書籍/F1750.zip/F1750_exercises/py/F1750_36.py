# F1750 練習 36
# 參考 income_tax.py

from income_tax import calculate_tax

print(calculate_tax(77000))
