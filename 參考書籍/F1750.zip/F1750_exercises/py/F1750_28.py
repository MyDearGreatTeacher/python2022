# F1750 練習 28

def abs_numbers(numbers):
    # return [abs(x) for x in numbers]
    return list(map(abs, numbers))

print(abs_numbers([1, -2, 3, -4, 5]))

