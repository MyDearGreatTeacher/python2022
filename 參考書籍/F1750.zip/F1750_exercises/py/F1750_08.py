# F1750 練習 08

def strsort(s):
    return ''.join(sorted(s))

print(strsort('python'))
